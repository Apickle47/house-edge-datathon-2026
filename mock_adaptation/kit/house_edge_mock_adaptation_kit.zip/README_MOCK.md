# MOCK House Edge adaptation kit (rehearsal only; not organizer data)

Built by Claude (Cowork) for a blind round-two rehearsal. The layout, scripts and checker match `main-participants-60-40.zip`. The data is synthetic, with **changed hidden rules** relative to the main round.

- `public/metadata.json`: round `adaptation`, max_points 40, season `5c719147f8b11fc50266ddc0`.
- Scale: 24 train, 24 validation and 48 test episodes per condition (stable, short_history, drift, shared_change), 8 machines each (768 / 768 / 1,536 queries). Splits use disjoint episodes and seeds.
- Train: queries, history, sampled labels, conditions. Validation: the same plus `targets.csv` (true probabilities) and `reference.csv` (official pooled starter, strength 20, fitted on this mock train). Test: queries, history and sample submission only.
- Test truth, test conditions and the test reference are **sealed** with Claude. Their SHA-256 values are listed in `MANIFEST.json`.
- Short-history machines show 40 recent consecutive ticks plus 24 sampled older ticks. All inputs are strictly before each query's cutoff.

Check a forecast:
```
python check_submission.py <file>.csv                       # test format check
python check_submission.py <file>.csv --split validation    # validation points out of 40
```
