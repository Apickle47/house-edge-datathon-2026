"""Offline inference for the House Edge probability forecast."""

import argparse
from bisect import bisect_left
from collections import defaultdict
import csv
import itertools
import json
import math
from pathlib import Path

PAYOUTS = (0, 1, 2, 5, 20)
COLUMNS = ["p_" + str(v) for v in PAYOUTS]


def logistic(x):
    return 1 / (1 + math.exp(-max(-50, min(50, x))))


def weights(scores):
    maximum = max(scores)
    raw = [math.exp(v - maximum) for v in scores]
    total = sum(raw)
    return [v / total for v in raw], maximum + math.log(total)


def load_rows(path):
    with open(path, newline="", encoding="utf-8-sig") as src:
        yield from csv.DictReader(src)


def episode_reader(folder):
    """Keep only one episode's spins in RAM, also for unsorted CSV input."""
    groups = defaultdict(list)
    for row in load_rows(folder / "queries.csv"):
        groups[row["episode_id"]].append(row)
    # The public kit groups rows by episode. Stream directly where possible.
    history = folder / "history.csv"
    seen = set()
    ordered = True
    for ep, block in itertools.groupby(load_rows(history), lambda r: r["episode_id"]):
        if ep in seen:
            ordered = False
            break
        seen.add(ep)
        for _ in block:
            pass
    if ordered:
        for ep, block in itertools.groupby(
            load_rows(history), lambda r: r["episode_id"]
        ):
            if ep in groups:
                seq = defaultdict(dict)
                for r in block:
                    seq[r["machine_id"]][int(r["tick"])] = int(r["payout"])
                yield groups.pop(ep), seq
    else:
        # Re-scan interleaved logs in bounded batches; the official runner limits scratch space.
        ids = iter(groups)
        while batch := list(itertools.islice(ids, 128)):
            blocks = {ep: defaultdict(dict) for ep in batch}
            for r in load_rows(history):
                if r["episode_id"] in blocks:
                    blocks[r["episode_id"]][r["machine_id"]][int(r["tick"])] = int(
                        r["payout"]
                    )
            for ep in batch:
                yield groups[ep], blocks[ep]
        return
    for queries in groups.values():
        yield queries, defaultdict(dict)


class Machine:
    def __init__(self, q, seq, model):
        self.q = q
        self.cut = int(q["cutoff"])
        self.seq = {t: v for t, v in seq.items() if t < self.cut}
        self.ticks = sorted(self.seq)
        self.typ = q["machine_type"]
        self.signal = int(q["signal"])
        self.weather_scale = model.get("weather_scale", 0.4)
        self.levels = model["levels"].get(self.typ, model["levels"]["*"])
        size_effect = model["size_effect"].get(self.typ, model["size_effect"]["*"])
        self.win = [
            [
                logistic(v + model["slope"] * self.signal + (s - 0.5) * size_effect)
                for s in (0, 1)
            ]
            for v in self.levels
        ]
        self.short = len(self.seq) < 0.7 * max(1, self.cut)
        self.hypotheses = []
        # A missing lag is marginalized with the observed win frequency.
        marginal = (2 + sum(v > 0 for v in self.seq.values())) / (4 + len(self.seq))
        for a, b, prior in model["pairs"]:

            def parity(t):
                va, vb = self.seq.get(t - a), self.seq.get(t - b)
                pa = marginal if va is None else float(va > 0)
                pb = marginal if vb is None else float(vb > 0)
                return pa + pb - 2 * pa * pb

            parities = [parity(t) for t in self.ticks]
            for size_prior, sizes, next_size in size_hypotheses(self, model, (a, b)):
                for sign in [1, -1]:
                    on = parities if sign == 1 else [1 - x for x in parities]
                    forward, reverse = [0.0], [0.0]
                    pf, pr = [], []
                    for t, x, s in zip(self.ticks, on, sizes):
                        lo, hi = [row[0] + s * (row[1] - row[0]) for row in self.win]
                        p = lo + x * (hi - lo)
                        z = lo + (1 - x) * (hi - lo)
                        pf.append(p)
                        pr.append(z)
                        if self.seq[t] == 0:
                            p, z = 1 - p, 1 - z
                        forward.append(forward[-1] + math.log(max(1e-12, p)))
                        reverse.append(reverse[-1] + math.log(max(1e-12, z)))
                    next_on = parity(self.cut)
                    if sign < 0:
                        next_on = 1 - next_on
                    self.hypotheses.append(
                        (
                            math.log(prior * 0.5) + size_prior,
                            on,
                            next_on,
                            forward,
                            reverse,
                            pf,
                            pr,
                            next_size,
                        )
                    )

    def candidate(self, switch):
        at = bisect_left(self.ticks, switch)
        scores = [h[0] + h[3][at] + h[4][-1] - h[4][at] for h in self.hypotheses]
        return weights(scores)

    def features(self, switches, episode_weights, local):
        joint = [[0.0, 0.0], [0.0, 0.0]]
        expected = [0.0] * len(self.ticks)
        history_win = [0.0] * len(self.ticks)
        for switch, sw, local_weights in zip(switches, episode_weights, local):
            at = bisect_left(self.ticks, switch)
            for h, prob in zip(self.hypotheses, local_weights):
                w = sw * prob
                if w < 1e-9:
                    continue
                _, on, nxt, _, _, pf, pr, sz = h
                active = nxt if switch > self.cut else 1 - nxt
                for k, pk in enumerate((1 - active, active)):
                    joint[k][0] += w * pk * (1 - sz)
                    joint[k][1] += w * pk * sz
                for j, x in enumerate(on):
                    expected[j] += w * (x if j < at else 1 - x)
                    history_win[j] += w * (pf[j] if j < at else pr[j])
        scales = (1e10, 48.0, 14.0, 4.0)
        residual, information = [0.0] * 6, [0.0] * 6
        for t, on, p in zip(self.ticks, expected, history_win):
            err = (self.seq[t] > 0) - p
            for i, scale in enumerate(scales):
                w = 1.0 if i == 0 else math.exp((t - self.cut) / scale)
                residual[i] += w * err
                information[i] += w * p * (1 - p)
            for i, fraction in enumerate((1 - on, on), 4):
                residual[i] += fraction * err
                information[i] += fraction * p * (1 - p)
        total = sum(map(sum, joint))
        self.history_win = history_win
        return [[x / total for x in row] for row in joint], residual, information


def win_features(machines):
    cutoff = machines[0].cut
    switches = [cutoff + 1] + sorted(
        set(int(cutoff * f / 100) for f in range(29, 92, 3))
    )
    logprior = [math.log(0.5)] + [math.log(0.5 / (len(switches) - 1))] * (
        len(switches) - 1
    )
    traces = [[m.candidate(c) for c in switches] for m in machines]
    ep_weights, _ = weights(
        [
            prior + sum(trace[j][1] for trace in traces)
            for j, prior in enumerate(logprior)
        ]
    )
    details = [
        m.features(switches, ep_weights, [a for a, _ in trace])
        for m, trace in zip(machines, traces)
    ]
    ep_r = [sum(d[1][j] for d in details) for j in range(4)]
    ep_i = [sum(d[2][j] for d in details) for j in range(4)]
    # A two-state filter pools timestamped evidence from all machines.
    # Compare switch rates by marginal likelihood, accounting for gaps in ticks.
    scale = machines[0].weather_scale
    times = defaultdict(float)
    for m in machines:
        for t, p in zip(m.ticks, m.history_win):
            if t < 8:
                continue
            a = p * (math.exp(scale) - 1) + 1
            b = p * (math.exp(-scale) - 1) + 1
            times[t] += math.log(b / a) + (2 * scale if m.seq[t] > 0 else 0.0)

    def update(hazard):
        hot = 0.5
        last = None
        evidence = 0.0
        for t, logratio in sorted(times.items()):
            if last is not None:
                hot = 0.5 + (hot - 0.5) * (1 - 2 * hazard) ** (t - last)
            probs, log_likelihood = weights(
                [math.log1p(-hot), math.log(hot) + logratio]
            )
            hot = probs[1]
            evidence += log_likelihood
            last = t
        if last is not None:
            hot = 0.5 + (hot - 0.5) * (1 - 2 * hazard) ** (cutoff - last)
        return evidence, (2 * hot - 1) * scale

    candidates = [update(rate) for rate in (0.008, 0.025, 0.07)]
    mix, _ = weights([v[0] for v in candidates])
    weather = sum(w * v[1] for w, v in zip(mix, candidates))
    for m, (on, res, info) in zip(machines, details):
        machine = [r / (3 + i) for r, i in zip(res, info)]
        shared = [
            (r - mr) / (8 + i - mi) for r, mr, i, mi in zip(ep_r, res, ep_i, info)
        ]
        yield on, [1.0, m.signal, *machine, *shared, weather]


def size_hypotheses(m, model, pair):
    table = model["sizes"].get(m.typ, model["sizes"]["*"])
    diffs = [math.log(b / a) for a, b in zip(*table)]
    rules = model.get("size_by_pair", {}).get(str(tuple(pair)), model["size_rules"])
    for a, b, ta, tb, op, prior_plus, prior_minus in rules:

        def state(t):
            x, y = m.seq.get(t - a), m.seq.get(t - b)
            if x is None or y is None:
                return 0.5
            x, y = x >= ta, y >= tb
            return float((x != y) if op == 0 else ((x or y) if op == 1 else (x and y)))

        history = [state(t) for t in m.ticks]
        d = sum(
            (s - 0.5) * diffs[PAYOUTS.index(m.seq[t]) - 1]
            for t, s in zip(m.ticks, history)
            if m.seq[t] > 0
        )
        s = state(m.cut)
        yield math.log(prior_plus) + d, history, s
        yield math.log(prior_minus) - d, [1 - x for x in history], 1 - s


def forecast(queries, hist, model):
    # A common cutoff is usual. Rebuild neighbor features at each requested cutoff.
    for cutoff in sorted({int(q["cutoff"]) for q in queries}):
        current = [q for q in queries if int(q["cutoff"]) == cutoff]
        machines = [Machine(q, hist.get(q["machine_id"], {}), model) for q in current]
        for m, (joint, feat) in zip(machines, win_features(machines)):
            coef = model["coef"].get(m.typ, model["coef"]["*"])
            size_effect = model["size_effect"].get(m.typ, model["size_effect"]["*"])
            table = model["sizes"].get(m.typ, model["sizes"]["*"])
            win_size = [0.0, 0.0]
            for k, row in enumerate(coef):
                intercept = sum(x * y for x, y in zip(feat, row))
                for s in (0, 1):
                    win_size[s] += joint[k][s] * logistic(
                        intercept + (s - 0.5) * size_effect
                    )
            yield [
                m.q["query_id"],
                max(0.0, 1 - sum(win_size)),
                *[win_size[0] * a + win_size[1] * b for a, b in zip(*table)],
            ]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--model", type=Path, default=Path(__file__).with_name("model.json"))
    p.add_argument("--split", choices=["test", "validation"], default="test")
    args = p.parse_args()
    model = json.loads(args.model.read_text())
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w", newline="", encoding="utf-8") as out:
        writer = csv.writer(out)
        writer.writerow(["query_id", *COLUMNS])
        for queries, hist in episode_reader(args.data / args.split):
            writer.writerows(forecast(queries, hist, model))


if __name__ == "__main__":
    main()
