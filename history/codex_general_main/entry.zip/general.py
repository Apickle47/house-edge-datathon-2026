"""Online alternatives for histories that differ from the training distribution."""

from functools import lru_cache
from itertools import combinations
from math import exp, lgamma, log


def normalize(values):
    peak = max(values)
    terms = [exp(x - peak) for x in values]
    total = sum(terms)
    return [x / total for x in terms], peak + log(total)


@lru_cache(maxsize=8192)
def gamma_half(count):
    return lgamma(0.5 + count) - lgamma(0.5)


def context_model(contexts, labels, classes):
    """Integrated likelihood and next probabilities for a categorical transition table.

    Contexts has one extra element for the forecast tick. An unknown lag is its
    own context. Each row uses a symmetric Dirichlet half-count prior.
    """
    counts = {}
    for context, label in zip(contexts, labels):
        if context not in counts:
            counts[context] = [0] * classes
        counts[context][label] += 1
    log_likelihood = sum(
        lgamma(classes * 0.5)
        - lgamma(sum(row) + classes * 0.5)
        + sum(gamma_half(n) for n in row)
        for row in counts.values()
    )
    target = counts.get(contexts[-1], [0] * classes)
    probs = [(0.5 + c) / (0.5 * classes + sum(target)) for c in target]
    return log_likelihood, probs


def mixture(candidates):
    weights, score = normalize([s for s, _ in candidates])
    probabilities = [
        sum(w * p for w, p in zip(weights, col))
        for col in zip(*(p for _, p in candidates))
    ]
    return score - log(len(candidates)), probabilities


def flexible(sequence, cutoff, size=False):
    classes = 4 if size else 2
    ticks = sorted(t for t, v in sequence.items() if not size or v > 0)
    payout_index = {1: 0, 2: 1, 5: 2, 20: 3}
    labels = [
        payout_index[sequence[t]] if size else int(sequence[t] > 0) for t in ticks
    ]
    times = ticks + [cutoff]
    stationary = context_model([0] * len(times), labels, classes)
    breaks = [
        context_model([int(t >= fraction * cutoff) for t in times], labels, classes)
        for fraction in (0.35, 0.5, 0.65, 0.8, 0.9)
    ]
    groups = [stationary, mixture(breaks)]
    lags = [[sequence.get(t - lag, -1) for t in times] for lag in range(1, 9)]
    single = []
    for threshold in (1, 2, 5):
        for lag in lags:
            keys = [-1 if x < 0 else int(x >= threshold) for x in lag]
            single.append(context_model(keys, labels, classes))
    groups.append(mixture(single))
    if not size:
        parity, full = [], []
        for a, b in combinations(lags, 2):
            cells = [
                -1 if x < 0 or y < 0 else 2 * (x > 0) + (y > 0) for x, y in zip(a, b)
            ]
            full.append(context_model(cells, labels, classes))
            parity.append(
                context_model(
                    [-1 if x < 0 else int(x in (1, 2)) for x in cells], labels, classes
                )
            )
        groups.extend([mixture(parity), mixture(full)])
    return mixture(groups)


def family_weights(log_odds):
    """Use other machines as evidence for how widespread a distribution shift is.

    The episode may mix familiar and unfamiliar machines. Integrate over its
    unknown proportion, with a prior favoring the released training population.
    """
    fractions = [0.01, 0.25, 0.75, 0.99]
    priors = [0.05, 0.1, 0.15, 0.70]
    totals = [log(p) for p in priors]
    conditional = []
    for odds in log_odds:
        probs = []
        for i, fraction in enumerate(fractions):
            weights, evidence = normalize([log(1 - fraction), log(fraction) + odds])
            totals[i] += evidence
            probs.append(weights[1])
        conditional.append(probs)
    family, _ = normalize(totals)
    return [sum(w * p for w, p in zip(family, row)) for row in conditional]
