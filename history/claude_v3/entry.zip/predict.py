"""Recreate the House Edge forecast: python predict.py --data <public dir> --out <csv>"""
import argparse, os
from housemodel import fit_constants, read_split, forecast, write_csv, CONFIG

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--split", default="test")
    a = ap.parse_args()
    size, lev, beta = fit_constants(a.data)
    queries, hist = read_split(a.data, a.split)
    preds = forecast(queries, hist, size, lev, beta, CONFIG)
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    write_csv(a.out, preds)
    print(f"wrote {len(preds)} forecasts to {a.out}")

if __name__ == "__main__":
    main()
