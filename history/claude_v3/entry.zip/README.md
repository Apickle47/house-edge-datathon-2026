# House Edge entry: XOR lag-pair on/off model (main round)

- Round: main
- Season ID: 5fffdc4d0c700bbf61c3f911
- Environment: `python` image, **Python standard library only** (tested with Python 3.13). No extra packages.
- Hardware: CPU only, about 20 seconds, well under 1 GB RAM. No randomness, so no seeds are needed (deterministic).

## Recreate the forecast

Run from the folder containing `predict.py`:

```sh
python predict.py --data /data --out /output/submission.csv
```

`--data` is the round's `public/` folder. The command reads `test/queries.csv` and `test/history.csv`, plus `validation/queries.csv` and `validation/targets.csv`, which it uses to estimate a few global constants: two payout-size regimes per machine type, on/off win levels, and the signal slope. Nothing is trained ahead of time, and there are no model files. Everything is recomputed from the public data on each run.

## Method (short)

- **Win chance:** each machine has a hidden on/off state. It is on when the machine's wins at two earlier ticks, (1,3), (2,5) or (4,7), satisfy XOR, or XNOR, depending on the machine. For each pair, a single XOR-vs-XNOR log-likelihood ratio is tracked with exponential forgetting, so the model can follow a reversal. On/off win levels are type-specific logits plus a signal shift. Bayesian model averaging combines the pairs, four memory lengths and three machine offsets, weighted by sequential predictive likelihood on the machine's own earlier ticks. A shared, recency-weighted episode logit shift is then estimated from all machines in the episode.
- **Payout size:** after a win, sizes follow one of two fixed distributions per type. The regime depends on whether payouts at two earlier ticks, (1,2), (1,4) or (2,4), were big (2x or more). It is learned per machine and averaged the same way.
- **Data use:** only ticks strictly before each query's cutoff are used for that query. Missing ticks are treated as unknown. Test answers are never used.

Validation (local checker): 57.14 / 60 points.
